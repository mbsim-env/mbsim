#include "hnurbsS.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES
  template class HNurbsSurface<double,3> ;
#endif

}
