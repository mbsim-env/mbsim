#include "hnurbsS_sp.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES
  template class HNurbsSurfaceSP<double,3> ;
#endif 

}
