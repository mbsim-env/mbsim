#include "nurbs_sp.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES

  template class NurbsCurveSP<double,3> ;

#endif 

}
