#include "nurbsS_sp.cpp"


namespace PLib { 

#ifdef NO_IMPLICIT_TEMPLATES

  template class NurbsSurfaceSP<float,3> ;

#endif 

}
