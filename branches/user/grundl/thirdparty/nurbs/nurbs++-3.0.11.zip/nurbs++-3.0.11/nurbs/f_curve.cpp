#include "curve.cpp"

namespace PLib {

#ifdef NO_IMPLICIT_TEMPLATES

  template class ParaCurve<float,2> ;
  template class ParaCurve<float,3> ;

#endif 

}
