#include "curve.cpp"

namespace PLib {
#ifdef NO_IMPLICIT_TEMPLATES
  template class ParaCurve<double,2> ;
  template class ParaCurve<double,3> ;
#endif 
}

